/* name: Jeff Brandon
 * andrewId: jdbrando@cmu.edu
 */

/* Struct representing a cache line. For this similations purposes
 * the block bits are not necessary because no data is actually being
 * referenced, instead the concern is weather or not a hit has occured.
 * age is used to store the relative age of the cache line, it is used
 * when choosing a victim for replacement.
 */
struct line{
   long tag;
   char valid;
   char age;
};
typedef struct line line;

/* Struct representing a set within the cache. It consists of a pointer
 * to the first line in the set and a killpointer, which  is the index of the
 * line to be evicted next.
 */
struct set{
   line *lines;
   short killptr;
};
typedef struct set set;

/* Struct representing a cache. It is simply a pointer to the first set
 * in the cache.
 */
struct cache{
   set *sets;
};
typedef struct cache cache;

//Used to store the number of sets in the cache
int setCount;	
//Used to store the number of lines in each set
int lineCount;	
//Global counts of cache evictions, hits, and misses
int evict, hit, miss; 
//Global variables used for arguments to main
char nWayAssociative, blockBits, indexBits;

#define VERBOSE 1 //I thought I would need more bitflags
#include "cachelab.h"
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
/* Main function: 
 *    Parameters:
 *       int argc - The count of parameters passed on the command line
 *       char * const* argv - the arguments passed
 *
 *    Main expects -s <int> -E <int> -b <int> -t <path> to be provided on the
 *    command line. Becuase these 8 values are expected and the function name 
 *    is also counted as an argument, if argc is less than 9 a usage message
 *    is printed and main exits with error status. If there are enough
 *    arguments then the arguments are parsed and stored in appropriate
 *    variables. If a parsing error occurs main prints an error message and 
 *    exits with error status. When parsing is successful the next step is to
 *    open the file located at the path specified on the command line. If the 
 *    call to fopen fails, a prompt is printed and the user is given a second 
 *    chance to enter in the path to the trace. If fopen fails again a message 
 *    is printed to stderr and main exits with error status. Next, initialize 
 *    the cache using the parameters read from the command line. If cache 
 *    initialization fails then main prints an error message to stderr and 
 *    exits with error status. At this point everything is ready to run the 
 *    cache simulation. While input is read from the trace file, the input is 
 *    parsed and handled accordingly. L and S generate one reference
 *    at the given address, M generates two references at the given address.
 *    After input from the trace is exhausted, the file is closed. cleanup
 *    is called on the cache pointer to free resources to the system, and 
 *    printSummary is called to show results of the simulation. Finally main
 *    exits with normal status.
 */
int main(int argc, char * const* argv){
   void cleanup(cache**);
   void displayUsage();
   int initCache(char, char, char, cache**);
   int reference(cache**, long, char, char);

   char bflag, byteCount, res, rType, *trace;
   long ref;
   FILE *inFile;
   cache *cache;
   hit = miss = evict = bflag = 0;
   
   if(argc < 9){
      displayUsage();
      exit(1);
   }   

   while((res = getopt(argc, argv, "hvs:E:b:t:")) >= 0){
      switch(res){
      case 'v':
         bflag |= VERBOSE;
         break;
      case 's':
         indexBits = strtol(optarg, NULL, 0);
         break;
      case 'E':
         nWayAssociative = strtol(optarg, NULL, 0);
         break;
      case 'b':
         blockBits = strtol(optarg, NULL, 0);
         break;
      case 't':
         trace = optarg;
         break;
      case 'h':
      default:
         displayUsage();
         exit(1);
      }
   }
   
   if((inFile = fopen(trace, "r")) == NULL){
      fprintf(stderr, "Unable to open tracefile: %s\n", trace);
      fprintf(stderr, "Please enter the correct file path now:");
      scanf("%s", trace);
      if((inFile = fopen(trace, "r")) == NULL){
         fprintf(stderr,"Couldn't open tracefile: %s\n",trace);
         fprintf(stderr,"Aborting cache simulation\n");
         exit(1);
      }
   }

   if(initCache(indexBits, nWayAssociative, blockBits, &cache)!=0){
      fprintf(stderr,"Unable to allocate sufficient memory\n");
      exit(1);
   }
   
   //run simulation
   while((res = fscanf(inFile, "%c %lx,%hhd", &rType, &ref, &byteCount)) != EOF){
      switch(rType){
      case 'M':
         reference(&cache, ref, bflag, 'M');
         reference(&cache, ref, bflag, 'M');
         break;
      case 'S':
         reference(&cache, ref, bflag, 'S');
         break;
      case 'L':
         reference(&cache, ref, bflag, 'L');
         break;
      }
   }

   fclose(inFile);
   cleanup(&cache); 
   printSummary(hit, miss, evict);
   exit(0);
}

/* cleanup
 *    Parameters:
 *       cache **cptr - adress of a pointer to a cache struct to be cleaned up
 *
 *    Cleanup takes the given cache and calls free on all of the pointers that
 *    were allocated earlier in the initCache function. This plays an important
 *    role because without this function system resources would be allocated to
 *    this process even after it completed.
 */
void cleanup(cache **cptr){
   cache *c = *cptr;
   int i;
   for(i = 0; i < setCount; i++) free(c->sets[i].lines);
   free(c->sets);
   free(c);
}

/* displayUsage
 *    displayUsage is a helper function that prints usage information
 *    to stderr. The message is designed to inform the user how command
 *    line input should be formatted.
 */
void displayUsage(){
   fprintf(stderr, "Usage: ./csim [-hv] -s <s> -E <E> ");
   fprintf(stderr, "-b <b> -t <tracefile>\n");
}

/* initCache
 *    Parameters:
 *       char indexBits - the number of index bits used to specify cache set
 *       char assoc - the number of lines in each cache set
 *       char blockBits - the number of bits the specify offset in datablock
 *       cache **c - address of a pointer to a cache struct to be initialized
 *    Returns:
 *       0 on success
 *       -1 on error
 *    
 *    initCache allocates memory for the cache to be simulated using malloc.
 *    First the cache struct is allocated, then the set pointer, and finally 
 *    the line pointers in each set. If at any point malloc fails, -1 is 
 *    returned immediately. initCache also initializes the global variables
 *    setCount, and lineCount which specify the number of sets, and cache lines 
 *    per set respectively. In addition to this, initCache sets the valid 'bits'
 *    in each line to 0 to specify invalidity. Age is initialized to 0 although
 *    as long as age is uniform among the lines in a set functionality is 
 *    preserved (except in the case of integer overflow). Each sets killptr is
 *    initialized to 0 too. Before returning successfully, the value at c is set
 *    to cptr, a local variable used in the initalization process, to simulate
 *    a pass by reference altering the value (*c).
 */
int initCache(char indexBits, char assoc, char blockBits, cache **c)
{  
   cache *cptr;
   set *ptr;
   line *p; 
   int i,j;
   setCount = 1<<indexBits;
   lineCount = assoc;
   if((cptr = malloc(sizeof(cache))) == NULL)
      return -1;
   if((cptr->sets = malloc(sizeof(set)*setCount))==NULL) 
      return -1;
   ptr = cptr->sets;
   i=0;
   while(i < setCount){
      if((ptr->lines = malloc(sizeof(line)*lineCount))==NULL)
         return -1;
      p = ptr->lines;
      j = 0;
      while(j < assoc){
         p->valid = 0;
         p->tag = 0;
         p->age = 0;
         p++;
         j++;
      }
      ptr->killptr = 0;
      ptr++;
      i++;
   }
   *c = cptr;
   return 0;
}
/* reference
 * 	Parameters:
 * 	   cache **cptr - adress to a pointer to the cache being simulated
 * 	   long ref - the 64 bit address being referneced
 * 	   char bflag - currently only holds VERBOSE bit, used for scalbility
 * 	   char type - specifies the type of reference, used for verbose mode
 * 	      printing
 * 	Returns:
 * 	   0 - there is no fail case
 *
 * 	reference simulates a memory reference specified by ref on a cache 
 * 	specified by cptr. Local variables are used as bitmasks and to store
 * 	the tag and index values when they are extracted from ref. Details on
 * 	tag and index extraction can be seen inline. Once this data has been
 * 	prepared, the cache set is determined using the index, then the lines
 * 	of the set are interated through to search for a hit. If a hit occurs,
 * 	the hitcount is incremented, the age of the line the hit occured at 
 * 	is set to 0, age is called to advance the age of the sets lines, 
 * 	and reference returns. 
 * 	If no hit occurs after checking each line a miss has occured and the 
 * 	miss count is incremented. At this point the lines of the set are 
 * 	iterated over again searching for an invalid cache line. If an invalid 
 * 	line is found the replacement is made at that line and reference 
 * 	returns. However if the lines are all valid an eviction must occur. 
 * 	The kill pointer is set, the replacement is made  and evict count is 
 * 	incremented. At this point reference will always return;
 */
int reference(cache **cptr, long ref, char bflag, char type){
   void age(set*);
   void setKillPtr(set*);
   void makeReplacement(set*,long);

   cache *c = *cptr;
   char v;
   int lc;
   long index, indexMask, tag, tagMask, val;
   set s;

   v = bflag & VERBOSE;
   val = ref;
   indexMask = tagMask = -1; // bitmask of all 1s
   //extract index bits
   val >>= blockBits;        //discard block address bits
   indexMask <<= indexBits;  //shift in indexBits 0s from the right
   indexMask = ~indexMask;   //bitwise not the mask to get a right aligned mask
                             //of length = indexBits
   index = indexMask & val;  //extract the index using mask 
   //extract tag
   val >>= indexBits;                        //discard indexing bitts
   tagMask <<= (64-(blockBits + indexBits)); //shift in 0s from the right equal
                                             //to the number of tag bits
   tagMask = ~tagMask;                       //bitwise not the mask to get a 
                                             //right aligned mask of length = 
                                             //tag bits 
   tag = tagMask & val;                      //extract the tag using mask

   //determine if it's a hit
   s = c->sets[index];
   for(lc = 0; lc < lineCount; lc++){
      if(s.lines[lc].valid && s.lines[lc].tag == tag){
         hit++;
         if(v){
            fprintf(stderr,"%c, 0x%.16lx, index:%lx, tag:", type, ref, index);
            fprintf(stderr,"%lx %s\n", tag, "hit");
         }
         s.lines[lc].age = 0;
         age(&s);
         return 0; //reference complete 
      }
   }
   miss++;//miss, choose a victim
   if(v){
      fprintf(stderr,"%c, 0x%.16lx, index:%lx, tag:", type, ref, index);
      fprintf(stderr,"%lx %s", tag, "miss");
   }
   for(lc = 0; lc < lineCount; lc++){
      if(!s.lines[lc].valid){
         s.killptr = lc;
         makeReplacement(&s,tag);
         fprintf(stderr,"\n");
         return 0; //cache updated replacing invalid line
      }   
   }
   setKillPtr(&s);
   makeReplacement(&s,tag);
   evict++; 
   if(v){
      fprintf(stderr," evict\n");
   }
   return 0; //cache updated evicting good data
}

/* makeReplacement
 *    Parameters:
 *       set *s - pointer to the set to replace a line in
 *       long tag - set the tag of the cache line to this value
 *
 *    makeReplacement takes a set and replaces the line specified by the sets
 *    kill pointer with the data specified by tag. First the tag of the 
 *    cache line pointed to by the sets killptr is set to the parameter tag.
 *    Next the lines valid bit is set and the age of the line is reset to 0.
 *    Finally the function age is called on the set to age its cache lines. 
 */
void makeReplacement(set *s, long tag){
   void age(set*);
   s->lines[s->killptr].tag = tag;
   s->lines[s->killptr].valid = 1;
   s->lines[s->killptr].age = 0;
   age(s);
}

/* age
 *    Parameters:
 *       set *s - the set to be aged
 *
 *    age iterates through the lines in the given set and increments the
 *    age of each line by one. This value is used when choosing a victim
 *    to evict.
 */
void age(set *s){
   int i;
   for(i=0; i < lineCount; i++)
      s->lines[i].age++;
}

/* setKillPtr
 *    Parameters:
 *       set *s - the set which needs to have  its killptr updated.
 *
 *    setKillPtr determines which cache line should be the next victim for
 *    replacement. To do this the index of the cache line with the largest
 *    age is found and killptr is set to that index. Thus the oldest cache
 *    line (the one that has been referenced the least recently) is evicted.
 */
void setKillPtr(set *s){
   int i, max, maxIndex;
   max = s->lines[0].age;
   for(i = 1, maxIndex = 0; i < lineCount; i++)
      if(s->lines[i].age > max){
         max = s->lines[i].age;
         maxIndex = i;
      }
   s->killptr = maxIndex;
}
